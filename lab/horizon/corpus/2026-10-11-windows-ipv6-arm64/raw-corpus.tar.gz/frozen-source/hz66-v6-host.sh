#!/bin/sh
# Bounded temporary alias for the operator-authorized Windows IPv6 lab.
set -eu
case "$(/sbin/ifconfig bridge101)" in
  *fd66:66:11::*) echo 'Lab IPv6 prefix already present; refusing to replace it.'; exit 1;;
esac
cleanup() { /sbin/ifconfig bridge101 inet6 fd66:66:11::1 -alias; }
/sbin/ifconfig bridge101 inet6 fd66:66:11::1 prefixlen 64 alias
trap cleanup EXIT
trap 'exit 1' INT TERM HUP
echo 'Temporary IPv6 lab address ready; leave this terminal open. Automatic removal within 600 seconds.'
i=0
while [ "$i" -lt 600 ] && [ ! -e /tmp/hz66-v6-host.done ]; do
  /bin/sleep 1
  i=$((i+1))
done
echo 'Removing temporary IPv6 lab address.'
