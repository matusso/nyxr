from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import time, json

payload = Path('/tmp/hz66-v6-bootstrap.ps1').read_bytes()
finished = False
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.client_address[0] != '192.168.254.130' or self.path != '/v6':
            self.send_error(404); return
        self.send_response(200)
        self.send_header('Content-Type', 'text/plain; charset=utf-8')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers(); self.wfile.write(payload)
        print('Fixed IPv6 helper delivered to authorized VM', flush=True)
    def do_POST(self):
        global finished
        size = int(self.headers.get('Content-Length', '0'))
        if self.client_address[0] != '192.168.254.130' or self.path != '/cleanup' or not 0 < size <= 65536:
            self.send_error(404); return
        value = json.loads(self.rfile.read(size))
        Path('/tmp/hz66-windows-ipv6-cleanup.json').write_text(json.dumps(value, indent=2)+'\n')
        self.send_response(200); self.end_headers(); self.wfile.write(b'ok')
        finished = True
        print('Native IPv6 cleanup telemetry received', flush=True)
    def log_message(self, *args): pass

with HTTPServer(('192.168.254.1', 18066), Handler) as server:
    server.timeout = 1
    deadline = time.monotonic()+1200
    print('Scoped IPv6 helper endpoint ready; bounded 20-minute deadline', flush=True)
    while not finished and time.monotonic() < deadline:
        server.handle_request()
print('IPv6 helper endpoint closed', flush=True)
