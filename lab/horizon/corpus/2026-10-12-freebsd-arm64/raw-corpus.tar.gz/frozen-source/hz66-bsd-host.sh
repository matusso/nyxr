#!/bin/sh
# Temporary alias for the operator-authorized BSD lab, at most 900 seconds.
set -eu
case "$(/sbin/ifconfig bridge101)" in
  *fd66:66:12::*) echo 'Lab IPv6 prefix already present; refusing to replace it.'; exit 1;;
esac
/sbin/ifconfig bridge101 inet6 fd66:66:12::1 prefixlen 64 alias
trap '/sbin/ifconfig bridge101 inet6 fd66:66:12::1 -alias' EXIT
trap 'exit 1' INT TERM HUP
echo 'BSD IPv6 source ready; leave this terminal open. Alias removed after the study or within 900 seconds.'
i=0
while [ "$i" -lt 900 ] && [ ! -e /tmp/hz66-bsd-host.done ]; do
  /bin/sleep 1
  i=$((i+1))
done
echo 'Removing temporary BSD lab source address.'
