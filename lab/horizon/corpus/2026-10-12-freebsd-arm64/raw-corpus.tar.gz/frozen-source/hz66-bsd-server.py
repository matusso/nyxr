from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import time

payloads = {
    '/start': Path('/tmp/hz66-bsd-start.sh').read_bytes(),
    '/bsd-endpoint.c': Path('/Users/burso/Stuff/matusso/nyxr/lab/horizon/live/bsd-endpoint.c').read_bytes(),
}
finished = False
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.client_address[0] != '192.168.254.131' or self.path not in payloads:
            self.send_error(404); return
        payload = payloads[self.path]
        self.send_response(200)
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers(); self.wfile.write(payload)
        print('Delivered fixed BSD helper component: '+self.path, flush=True)
    def do_POST(self):
        global finished
        size = int(self.headers.get('Content-Length', '0'))
        if self.client_address[0] != '192.168.254.131' or self.path != '/guest-artifacts' or not 0 < size <= 1048576:
            self.send_error(404); return
        Path('/tmp/hz66-bsd-guest-artifacts.tar.gz').write_bytes(self.rfile.read(size))
        self.send_response(200); self.end_headers(); self.wfile.write(b'ok\n')
        finished = True
        print('Native BSD evidence and cleanup received', flush=True)
    def log_message(self, *args): pass

with HTTPServer(('192.168.254.1', 18066), Handler) as server:
    server.timeout = 1
    deadline = time.monotonic()+1800
    print('Scoped BSD helper endpoint ready; 30-minute deadline', flush=True)
    while not finished and time.monotonic() < deadline:
        server.handle_request()
print('BSD helper endpoint closed', flush=True)
