#!/bin/sh
# Fixed temporary fixture for this operator-authorized VM; no guest shell API.
set -eu
umask 077
work=$(mktemp -d /tmp/nyxr-hz66-bsd.XXXXXX)
original=$(/sbin/sysctl -n net.inet.tcp.sack.enable)
case "$original" in 0|1) ;; *) echo 'Native SACK control unavailable'; exit 1;; esac
added=0
helper_pid=
cleanup() {
  trap - EXIT
  set +e
  if [ -n "$helper_pid" ] && kill -0 "$helper_pid" 2>/dev/null; then
    kill -TERM "$helper_pid"
    wait "$helper_pid"
  fi
  /sbin/sysctl net.inet.tcp.sack.enable="$original"
  if [ "$added" -eq 1 ]; then /sbin/ifconfig em0 inet6 fd66:66:12::2 -alias; fi
  current=$(/sbin/sysctl -n net.inet.tcp.sack.enable)
  {
    echo "original_sack=$original"
    echo "current_sack=$current"
    if [ "$original" = "$current" ]; then echo 'sack_restored=true'; else echo 'sack_restored=false'; fi
    if /sbin/ifconfig em0 | /usr/bin/grep -q 'fd66:66:12::2'; then echo 'guest_ula_removed=false'; else echo 'guest_ula_removed=true'; fi
    echo '--- listener snapshot ---'
    /usr/bin/sockstat -46l -p 443
    echo '--- interface after ---'
    /sbin/ifconfig em0
    echo '--- routes after ---'
    /usr/bin/netstat -rn
  } > "$work/cleanup.txt"
  /bin/cat "$work/cleanup.txt"
  /usr/bin/tar -czf "$work/artifacts.tar.gz" -C "$work" helper.c helper compiler.log environment-before.txt helper.log cleanup.txt
  if [ -f "$work/artifacts.tar.gz" ]; then
    bytes=$(/usr/bin/wc -c < "$work/artifacts.tar.gz" | /usr/bin/tr -d ' ')
    {
      printf 'POST /guest-artifacts HTTP/1.0\r\nHost: 192.168.254.1\r\nContent-Length: %s\r\nContent-Type: application/gzip\r\n\r\n' "$bytes"
      /bin/cat "$work/artifacts.tar.gz"
    } | /usr/bin/nc -N -w 5 192.168.254.1 18066
  fi
  echo "BSD fixture finished; guest evidence retained in $work"
}
trap cleanup EXIT
trap 'exit 1' INT TERM HUP
{
  /usr/bin/uname -a
  /bin/freebsd-version -kru
  /sbin/ifconfig em0
  /usr/bin/netstat -rn
  /sbin/sysctl net.inet.tcp.sack.enable
} > "$work/environment-before.txt"
if /sbin/ifconfig em0 | /usr/bin/grep -q 'fd66:66:12::2'; then echo 'Guest lab ULA already exists; refusing to replace it'; exit 1; fi
/usr/bin/fetch -o "$work/helper.c" http://192.168.254.1:18066/bsd-endpoint.c
/usr/bin/cc -O2 -Wall -Wextra -Werror -o "$work/helper" "$work/helper.c" > "$work/compiler.log" 2>&1
{
  /usr/bin/cc --version
  /sbin/sha256 "$work/helper.c" "$work/helper"
} >> "$work/compiler.log"
/sbin/ifconfig em0 inet6 fd66:66:12::2 prefixlen 64 alias
added=1
i=0
while /sbin/ifconfig em0 | /usr/bin/grep 'fd66:66:12::2' | /usr/bin/grep -q tentative; do
  i=$((i+1))
  if [ "$i" -gt 100 ]; then echo 'Guest IPv6 duplicate-address detection did not finish'; exit 1; fi
  /bin/sleep .1
done
"$work/helper" em0 192.168.254.131 192.168.254.1 fd66:66:12::2 fd66:66:12::1 900 > "$work/helper.log" 2>&1 &
helper_pid=$!
echo "Bounded BSD fixture starting; evidence directory $work"
wait "$helper_pid"
