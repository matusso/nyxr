# Native Windows TCP fixture. Run in an elevated PowerShell console.
# No TCP feature is changed. The one temporary firewall rule is peer/address scoped.
param(
    [Parameter(Mandatory=$true)][string]$LocalAddress,
    [Parameter(Mandatory=$true)][string]$PeerAddress,
    [ValidateRange(60,1800)][int]$Seconds = 600
)
$ErrorActionPreference = 'Stop'
$local = [System.Net.IPAddress]::Parse($LocalAddress)
$peer = [System.Net.IPAddress]::Parse($PeerAddress)
if ($local.AddressFamily -ne 'InterNetwork' -or $peer.AddressFamily -ne 'InterNetwork') {
    throw 'This exploratory fixture supports IPv4 only.'
}
foreach ($ip in @($local,$peer)) {
    $octets = $ip.GetAddressBytes()
    if (-not ($octets[0] -eq 10 -or ($octets[0] -eq 172 -and $octets[1] -ge 16 -and $octets[1] -le 31) -or
        ($octets[0] -eq 192 -and $octets[1] -eq 168))) { throw 'Use an operator-owned RFC1918 virtual segment.' }
}
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'An elevated console is required for the temporary scoped firewall rule.'
}
$address = Get-NetIPAddress -IPAddress $LocalAddress -AddressFamily IPv4
if (@($address).Count -ne 1) { throw 'Local address is not uniquely assigned.' }
$fixture = [guid]::NewGuid().ToString()
$ruleName = 'nyxr-hz66-' + $fixture
$listener = New-Object System.Net.Sockets.TcpListener($local,443)
$createdRule = $false
function Get-Truth {
    $os = Get-CimInstance Win32_OperatingSystem
    $rule = Get-NetFirewallRule -Name $ruleName -ErrorAction SilentlyContinue
    [ordered]@{
        fixture = $fixture; utc = [DateTime]::UtcNow.ToString('o'); pid = $PID
        platform = 'Windows'; caption = $os.Caption; version = $os.Version
        build = $os.BuildNumber; architecture = $os.OSArchitecture
        local_address = $LocalAddress; peer_address = $PeerAddress; port = 443
        addresses = @(Get-NetIPAddress -InterfaceIndex $address.InterfaceIndex |
            Select-Object IPAddress,AddressFamily,PrefixLength,AddressState)
        routes = @(Get-NetRoute -InterfaceIndex $address.InterfaceIndex |
            Select-Object DestinationPrefix,NextHop,RouteMetric)
        adapter = Get-NetAdapter -InterfaceIndex $address.InterfaceIndex |
            Select-Object InterfaceDescription,MacAddress,Status,LinkSpeed
        tcp_settings = @(Get-NetTCPSetting | Select-Object SettingName,AutoTuningLevelLocal,
            CongestionProvider,EcnCapability,Timestamps)
        tcp_global = (netsh interface tcp show global | Out-String)
        sack_setting = 'Native Windows default; not independently configurable by this helper'
        firewall_profiles = @(Get-NetFirewallProfile | Select-Object Name,Enabled,
            DefaultInboundAction,DefaultOutboundAction)
        fixture_rule_present = [bool]$rule
        fixture_rule = @($rule | Select-Object Name,Enabled,Direction,Action)
        fixture_addresses = @($rule | Get-NetFirewallAddressFilter |
            Select-Object LocalAddress,RemoteAddress)
        fixture_ports = @($rule | Get-NetFirewallPortFilter |
            Select-Object Protocol,LocalPort,RemotePort)
    }
}
try {
    # Bind first: never replace an existing listener on the chosen address/port.
    $listener.Start()
    New-NetFirewallRule -Name $ruleName -DisplayName $ruleName -Direction Inbound `
        -Action Allow -Protocol TCP -LocalAddress $LocalAddress -RemoteAddress $PeerAddress `
        -LocalPort 443 -Profile Any | Out-Null
    $createdRule = $true
    $deadline = [DateTime]::UtcNow.AddSeconds($Seconds)
    Write-Host "HORIZON fixture $fixture listening on ${LocalAddress}:443 for $PeerAddress; expires in $Seconds seconds."
    Write-Host 'Leave this console open. Ctrl+C stops it and removes its rule.'
    while ([DateTime]::UtcNow -lt $deadline) {
        if (-not $listener.Pending()) { Start-Sleep -Milliseconds 25; continue }
        $client = $listener.AcceptTcpClient()
        try {
            if ($client.Client.RemoteEndPoint.Address.ToString() -ne $PeerAddress) { continue }
            $stream = $client.GetStream()
            $stream.ReadTimeout = 2000
            $stream.WriteTimeout = 2000
            $reader = New-Object IO.StreamReader($stream)
            # Only fixed telemetry/stop messages are accepted, never code or paths.
            $request = ''
            while ($request.Length -lt 16) {
                $character = $reader.Read()
                if ($character -lt 0 -or $character -eq 10) { break }
                $request += [char]$character
            }
            if ($request.Trim() -eq 'TRUTH') { $response = Get-Truth }
            elseif ($request.Trim() -eq 'STOP') {
                Remove-NetFirewallRule -Name $ruleName
                $createdRule = $false
                $response = Get-Truth
                $deadline = [DateTime]::UtcNow
            } else { continue }
            $bytes = [Text.Encoding]::UTF8.GetBytes(($response | ConvertTo-Json -Depth 8 -Compress) + "`n")
            $stream.Write($bytes,0,$bytes.Length)
        } catch [System.IO.IOException] {
            # Raw SYN baselines never send an application request.
        } finally { $client.Dispose() }
    }
} finally {
    $listener.Stop()
    if ($createdRule) { Remove-NetFirewallRule -Name $ruleName }
    Write-Host "HORIZON fixture stopped; temporary rule $ruleName removed."
}
