package pipeline

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"io"
	"net"
	"net/netip"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/gopacket/gopacket"
	"github.com/gopacket/gopacket/layers"

	"github.com/matusso/nyxr/internal/config"
	"github.com/matusso/nyxr/internal/nmapdb"
	"github.com/matusso/nyxr/internal/nse"
	"github.com/matusso/nyxr/internal/observe"
	"github.com/matusso/nyxr/internal/packetio"
	"github.com/matusso/nyxr/internal/scan"
	"github.com/matusso/nyxr/internal/storage"
)

type fakeNSERunner struct {
	validated bool
	ports     []nse.Port
}

func TestFingerprintPipelinePassesStackEvidenceToSinks(t *testing.T) {
	for _, mode := range []string{"syn", "connect"} {
		off := false
		r, err := (config.Request{Targets: []string{"192.0.2.7"}, Ports: "443", Protocols: "tcp", TCPMode: mode, Interface: "fixture", Fingerprint: true, Service: &off}).Resolve(config.ResolveOptions{})
		if err != nil {
			t.Fatal(err)
		}
		var output bytes.Buffer
		opts := FromResolved(r)
		opts.Sinks = []Sink{NewJSONSink(&output)}
		opts.Discover = func(_ context.Context, cfg config.Config, emit func(scan.Observation) error) error {
			if cfg.StackFingerprint != (mode == "syn") {
				t.Errorf("fingerprint not tied to raw SYN: %+v", cfg)
			}
			o := scan.Observation{Target: r.Config.Targets[0], Transport: "tcp", Port: 443, State: "open", Confidence: 100, Probe: "tcp-syn"}
			if cfg.StackFingerprint {
				o.TCPStack = &observe.TCPStack{Signature: "native", Status: observe.FingerprintUnknown}
			}
			return emit(o)
		}
		_, err = Run(context.Background(), r.Config, opts)
		if err != nil {
			t.Fatal(err)
		}
		_, records := decodeKinds(t, output.Bytes())
		if (records[0]["tcp_stack"] != nil) != (mode == "syn") {
			t.Fatalf("stack lost or fabricated: %+v", records)
		}
	}
}

func TestCancelledDiscoveryRetainsStackRepliesWithoutNewServiceWork(t *testing.T) {
	on := true
	r, err := (config.Request{Targets: []string{"192.0.2.7"}, Ports: "80,443", Protocols: "tcp", TCPMode: "syn", Interface: "fixture", Fingerprint: true, Service: &on, ServiceProbes: "banner"}).Resolve(config.ResolveOptions{})
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	var output bytes.Buffer
	opts := FromResolved(r)
	opts.Sinks = []Sink{NewJSONSink(&output)}
	opts.ServiceDial = func(context.Context, string, string) (net.Conn, error) {
		t.Error("service work started after cancellation")
		return nil, errors.New("cancelled")
	}
	opts.Discover = func(_ context.Context, _ config.Config, emit func(scan.Observation) error) error {
		cancel()
		for _, port := range []uint16{80, 443} {
			if err := emit(scan.Observation{Target: r.Config.Targets[0], Transport: "tcp", Port: port, State: "open", Confidence: 100, Probe: "tcp-syn", TCPStack: &observe.TCPStack{Status: observe.FingerprintUnknown, Signature: "native"}}); err != nil {
				return err
			}
		}
		return context.Canceled
	}
	summary, err := Run(ctx, r.Config, opts)
	if err != context.Canceled || summary.Observations != 2 {
		t.Fatalf("cancelled replies lost: %+v %v", summary, err)
	}
}

func (f *fakeNSERunner) Validate(_ context.Context, cfg config.NSE) error {
	f.validated = cfg.Enabled()
	return nil
}

func (f *fakeNSERunner) RunHost(_ context.Context, _ config.NSE, addr netip.Addr, ports []nse.Port, _ int) ([]observe.Observation, error) {
	f.ports = append(f.ports, ports...)
	return []observe.Observation{{Kind: observe.KindScript, Target: addr, Transport: "tcp", Port: ports[0].Number,
		State: "reported", Probe: "nse/http-title", NSE: &observe.NSEResult{ID: "http-title", Output: "Welcome"}}}, nil
}

func TestNSEReceivesOnlyDiscoveredOpenPorts(t *testing.T) {
	resolved, err := (config.Request{Targets: []string{"127.0.0.1"}, Ports: "80,81", Protocols: "tcp", NSEScripts: "http-title"}).Resolve(config.ResolveOptions{})
	if err != nil {
		t.Fatal(err)
	}
	fake := &fakeNSERunner{}
	var output bytes.Buffer
	addr := netip.MustParseAddr("127.0.0.1")
	opts := FromResolved(resolved)
	opts.NSERunner = fake
	opts.Sinks = []Sink{NewJSONSink(&output)}
	opts.Discover = func(_ context.Context, _ config.Config, emit func(scan.Observation) error) error {
		for _, item := range []struct {
			port  uint16
			state string
		}{{80, "open"}, {81, "closed"}} {
			if err := emit(scan.Observation{Target: addr, Transport: "tcp", Port: item.port, State: item.state}); err != nil {
				return err
			}
		}
		return nil
	}
	summary, err := Run(context.Background(), resolved.Config, opts)
	if err != nil {
		t.Fatal(err)
	}
	if !fake.validated || len(fake.ports) != 1 || fake.ports[0].Number != 80 || summary.Observations != 3 {
		t.Fatalf("NSE pipeline did not select just the open port: runner=%+v summary=%+v", fake, summary)
	}
	_, records := decodeKinds(t, output.Bytes())
	if records[2]["kind"] != observe.KindScript || records[2]["nse"].(map[string]any)["output"] != "Welcome" {
		t.Fatalf("missing NSE result: %+v", records)
	}
}

func TestUDPProtocolDSLVerifiesOpenFilteredPort(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "udp-protocol.yaml")
	definition := "schema: nyxr/protocol/v1\nprotocol: udp_identity\ntransport: udp\nports: [9999]\nsteps:\n  - send: {text: PING}\n  - receive: {max_bytes: 4}\n  - expect: {prefix: PONG}\n"
	if err := os.WriteFile(path, []byte(definition), 0o600); err != nil {
		t.Fatal(err)
	}
	on := true
	resolved, err := (config.Request{Targets: []string{"127.0.0.1"}, Profile: "udp-basic", Ports: "9999", Service: &on, ProtocolDefinitions: filepath.Base(path)}).Resolve(config.ResolveOptions{BaseDir: dir})
	if err != nil {
		t.Fatal(err)
	}
	var output bytes.Buffer
	opts := FromResolved(resolved)
	opts.Sinks = []Sink{NewJSONSink(&output)}
	opts.Discover = func(_ context.Context, _ config.Config, emit func(scan.Observation) error) error {
		return emit(scan.Observation{Target: netip.MustParseAddr("127.0.0.1"), Transport: "udp", Port: 9999, State: "open|filtered"})
	}
	opts.ServiceDial = func(ctx context.Context, network, address string) (net.Conn, error) {
		if network != "udp" {
			t.Errorf("wrong network: %s", network)
		}
		client, server := net.Pipe()
		go func() {
			defer server.Close()
			var request [4]byte
			_, _ = io.ReadFull(server, request[:])
			_, _ = server.Write([]byte("PONG"))
		}()
		return client, nil
	}
	summary, err := Run(context.Background(), resolved.Config, opts)
	if err != nil {
		t.Fatal(err)
	}
	if summary.Services != 1 {
		t.Fatalf("expected verified service: %+v", summary)
	}
	_, records := decodeKinds(t, output.Bytes())
	if len(records) < 2 || records[1]["kind"] != observe.KindService || records[1]["state"] != "open" || records[1]["service"] != "udp_identity" {
		t.Fatalf("UDP observation was not upgraded by DSL: %+v", records)
	}
}

func sshServer(t *testing.T) (netip.Addr, uint16) {
	t.Helper()
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = ln.Close() })
	go func() {
		for {
			c, err := ln.Accept()
			if err != nil {
				return
			}
			_, _ = io.WriteString(c, "SSH-2.0-OpenSSH_9.6\r\n")
			_ = c.Close()
		}
	}()
	ap := netip.MustParseAddrPort(ln.Addr().String())
	return ap.Addr(), ap.Port()
}

func ftpServer(t *testing.T) (netip.Addr, uint16) {
	t.Helper()
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = ln.Close() })
	go func() {
		for {
			c, err := ln.Accept()
			if err != nil {
				return
			}
			_, _ = io.WriteString(c, "220 ProFTPD 1.3.5 Server ready.\r\n")
			time.Sleep(200 * time.Millisecond)
			_ = c.Close()
		}
	}()
	ap := netip.MustParseAddrPort(ln.Addr().String())
	return ap.Addr(), ap.Port()
}

func TestNmapServiceProbesEndToEnd(t *testing.T) {
	addr, open := ftpServer(t)
	path := filepath.Join(t.TempDir(), "nmap-service-probes")
	probes := "Probe TCP NULL q||\nmatch ftp m|^220[- ].*ProFTPD ([\\w.]+)| p/ProFTPD/ v/$1/\n"
	if err := os.WriteFile(path, []byte(probes), 0o644); err != nil {
		t.Fatal(err)
	}
	rate := 0
	cfg, err := config.Build(config.Options{Targets: []string{"127.0.0.1"}, Profile: "tcp-common",
		Ports: strconv.Itoa(int(open)), Rate: &rate})
	if err != nil {
		t.Fatal(err)
	}
	svc, err := config.BuildService(cfg, config.ServiceOptions{Timeout: "1s", NmapProbes: path})
	if err != nil {
		t.Fatal(err)
	}
	db, err := nmapdb.LoadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	var out bytes.Buffer
	summary, err := Run(context.Background(), cfg, Options{Service: svc, Nmap: db, Sinks: []Sink{NewJSONSink(&out)}})
	if err != nil {
		t.Fatal(err)
	}
	if summary.Services != 1 {
		t.Fatalf("expected one identified service: %+v", summary)
	}
	_, records := decodeKinds(t, out.Bytes())
	found := false
	for _, r := range records {
		if r["kind"] == "service" {
			if r["service"] != "ftp" || r["product"] != "ProFTPD" || r["version"] != "1.3.5" {
				t.Fatalf("nmap did not identify the service: %v", r)
			}
			found = true
		}
	}
	if !found {
		t.Fatalf("no service record for %s:%d", addr, open)
	}
}

func serviceConfig(t *testing.T, port uint16, extra ...uint16) (config.Config, config.Service) {
	t.Helper()
	ports := []string{strconv.Itoa(int(port))}
	for _, p := range extra {
		ports = append(ports, strconv.Itoa(int(p)))
	}
	rate := 0
	cfg, err := config.Build(config.Options{Targets: []string{"127.0.0.1"}, Profile: "tcp-common", Ports: strings.Join(ports, ","), Rate: &rate})
	if err != nil {
		t.Fatal(err)
	}
	svc, err := config.BuildService(cfg, config.ServiceOptions{Timeout: "1s"})
	if err != nil {
		t.Fatal(err)
	}
	return cfg, svc
}

// decodeKinds splits an NDJSON stream into record kinds, in order.
func decodeKinds(t *testing.T, data []byte) ([]string, []map[string]any) {
	t.Helper()
	var kinds []string
	var records []map[string]any
	sc := bufio.NewScanner(bytes.NewReader(data))
	sc.Buffer(nil, 1<<20)
	for sc.Scan() {
		var m map[string]any
		if err := json.Unmarshal(sc.Bytes(), &m); err != nil {
			t.Fatalf("bad NDJSON line %q: %v", sc.Text(), err)
		}
		if m["schema"] != observe.SchemaVersion {
			t.Fatalf("record without schema version: %v", m)
		}
		kinds = append(kinds, m["kind"].(string))
		records = append(records, m)
	}
	return kinds, records
}

func TestConnectScanFeedsServiceProbesAndStore(t *testing.T) {
	addr, open := sshServer(t)
	ln, _ := net.Listen("tcp", "127.0.0.1:0")
	closed := uint16(ln.Addr().(*net.TCPAddr).Port)
	_ = ln.Close()
	cfg, svc := serviceConfig(t, open, closed)

	store, err := storage.Open(context.Background(), filepath.Join(t.TempDir(), "nyxr.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer store.Close()
	var out bytes.Buffer
	summary, err := Run(context.Background(), cfg, Options{Service: svc, Sinks: []Sink{NewJSONSink(&out), NewStoreSink(context.Background(), store)}})
	if err != nil {
		t.Fatal(err)
	}
	if summary.Status != "completed" || summary.Observations != 3 || summary.Services != 1 {
		t.Fatalf("summary %+v", summary)
	}
	kinds, records := decodeKinds(t, out.Bytes())
	if strings.Join(kinds, ",") != "port,port,service,scan" && strings.Join(kinds, ",") != "port,service,port,scan" {
		t.Fatalf("record order %v", kinds)
	}
	for _, r := range records {
		if r["kind"] == "service" && (r["product"] != "OpenSSH" || r["port"].(float64) != float64(open)) {
			t.Fatalf("service record %v", r)
		}
	}

	stored, err := store.Observations(context.Background(), storage.Filter{ScanID: summary.ID, Kind: observe.KindService})
	if err != nil || len(stored) != 1 || stored[0].Target != addr || len(stored[0].Evidence) == 0 {
		t.Fatalf("stored service: %+v %v", stored, err)
	}
	scans, _ := store.Scans(context.Background(), 1)
	if len(scans) != 1 || scans[0].Status != "completed" || scans[0].Services != 1 {
		t.Fatalf("stored scan %+v", scans)
	}
}

// fakeCapture replays frames once and then idles.
type fakeCapture struct {
	mu     sync.Mutex
	frames [][]byte
}

func (f *fakeCapture) ReceiveBatch(ctx context.Context, b [][]byte) (int, error) {
	f.mu.Lock()
	n := 0
	for n < len(b) && len(f.frames) > 0 {
		b[n] = b[n][:copy(b[n], f.frames[0])]
		f.frames = f.frames[1:]
		n++
	}
	f.mu.Unlock()
	if n == 0 {
		select {
		case <-ctx.Done():
			return 0, ctx.Err()
		case <-time.After(time.Millisecond):
		}
	}
	return n, nil
}
func (f *fakeCapture) SendBatch(context.Context, [][]byte) (int, error) { return 0, nil }
func (f *fakeCapture) Stats() packetio.Stats                            { return packetio.Stats{} }
func (f *fakeCapture) Close() error                                     { return nil }

func synFrame(t *testing.T, src, dst netip.Addr, sport, dport uint16, ack bool) []byte {
	eth := &layers.Ethernet{SrcMAC: net.HardwareAddr{2, 0, 0, 0, 0, 1}, DstMAC: net.HardwareAddr{2, 0, 0, 0, 0, 2}, EthernetType: layers.EthernetTypeIPv4}
	ip := &layers.IPv4{Version: 4, TTL: 64, Protocol: layers.IPProtocolTCP, SrcIP: src.AsSlice(), DstIP: dst.AsSlice()}
	tcp := &layers.TCP{SrcPort: layers.TCPPort(sport), DstPort: layers.TCPPort(dport), SYN: true, ACK: ack}
	_ = tcp.SetNetworkLayerForChecksum(ip)
	buf := gopacket.NewSerializeBuffer()
	if err := gopacket.SerializeLayers(buf, gopacket.SerializeOptions{FixLengths: true, ComputeChecksums: true}, eth, ip, tcp); err != nil {
		t.Fatal(err)
	}
	return append([]byte(nil), buf.Bytes()...)
}

func TestCaptureEvidenceLinkedAfterObservations(t *testing.T) {
	target := netip.MustParseAddr("192.0.2.9")
	local := netip.MustParseAddr("192.0.2.1")
	cfg, err := config.Build(config.Options{Targets: []string{target.String()}, Profile: "tcp-basic", Ports: "443"})
	if err != nil {
		t.Fatal(err)
	}
	src := &fakeCapture{frames: [][]byte{synFrame(t, local, target, 50000, 443, false), synFrame(t, target, local, 443, 50000, true)}}
	discover := func(ctx context.Context, _ config.Config, emit func(scan.Observation) error) error {
		for {
			src.mu.Lock()
			done := len(src.frames) == 0
			src.mu.Unlock()
			if done {
				break
			}
			time.Sleep(time.Millisecond)
		}
		return emit(scan.Observation{Timestamp: time.Now(), Target: target, Transport: "tcp", Port: 443, State: "open", Confidence: 100})
	}
	path := filepath.Join(t.TempDir(), "scan.pcapng")
	var out bytes.Buffer
	summary, err := Run(context.Background(), cfg, Options{
		Capture: &CaptureOptions{Path: path, Interface: "fake0"}, Discover: discover,
		OpenCapture: func(string) (packetio.PacketIO, error) { return src, nil },
		Sinks:       []Sink{NewJSONSink(&out)}, CaptureGrace: time.Millisecond,
	})
	if err != nil {
		t.Fatal(err)
	}
	kinds, records := decodeKinds(t, out.Bytes())
	if strings.Join(kinds, ",") != "port,packet-evidence,scan" {
		t.Fatalf("record order %v", kinds)
	}
	pe := records[1]
	if pe["scan_id"] != summary.ID || pe["port"].(float64) != 443 || len(pe["packets"].([]any)) != 2 || pe["capture"] != path {
		t.Fatalf("packet evidence %v", pe)
	}
	if summary.Capture == nil || summary.Capture.Written != 2 || summary.Capture.FlowsIndexed != 1 {
		t.Fatalf("capture stats %+v", summary.Capture)
	}
}

func TestCaptureRequiresInterface(t *testing.T) {
	cfg, _ := config.Build(config.Options{Targets: []string{"192.0.2.9"}, Profile: "tcp-basic"})
	var out bytes.Buffer
	summary, err := Run(context.Background(), cfg, Options{Capture: &CaptureOptions{Path: "x.pcapng"}, Sinks: []Sink{NewTextSink(&out)},
		Discover: func(context.Context, config.Config, func(scan.Observation) error) error {
			t.Fatal("discovery must not start without capture")
			return nil
		}})
	if err == nil || !strings.Contains(err.Error(), "requires --interface") || summary.Status != "failed" {
		t.Fatalf("got %v, %+v", err, summary)
	}
	if !strings.Contains(out.String(), "failed") {
		t.Fatalf("failure summary not printed: %q", out.String())
	}
}

type failingSink struct{ JSONSink }

func (failingSink) Observation(observe.Observation) error { return errors.New("disk full") }

func TestSinkErrorStopsDiscovery(t *testing.T) {
	cfg, _ := config.Build(config.Options{Targets: []string{"192.0.2.9"}, Profile: "tcp-basic", Ports: "1-100"})
	var emitted int
	_, err := Run(context.Background(), cfg, Options{
		Sinks: []Sink{&failingSink{*NewJSONSink(io.Discard)}},
		Discover: func(ctx context.Context, _ config.Config, emit func(scan.Observation) error) error {
			for i := 0; i < 100; i++ {
				emitted++
				if err := emit(scan.Observation{Target: netip.MustParseAddr("192.0.2.9"), Transport: "tcp", Port: uint16(i + 1), State: "closed"}); err != nil {
					return err
				}
			}
			return nil
		}})
	if err == nil || err.Error() != "disk full" || emitted != 1 {
		t.Fatalf("got %v after %d emits", err, emitted)
	}
}
