# Setup failure retained

The first approved namespace attempt failed before any active HZ-001 or scanner measurement because Docker mounted /proc/sys read-only. No report or packet capture exists for this attempt. One planned run was started and failed; the second was never started. The collector was fixed to remount procfs only in the private per-invocation mount namespace. These setup outcomes are retained and excluded from live inference claims.
